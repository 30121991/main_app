from Model import db,ma,Phone,Email,User

class PhoneSchema(ma.ModelSchema):
    class Meta:
        model = Phone
        sqla_session = db.session
        load_instance=True

class EmailSchema(ma.ModelSchema):
    class Meta:
        model = Email
        sqla_session = db.session
        load_instance=True
        
class UserSchema(ma.ModelSchema):

    class Meta:
        model = User
        sqla_session = db.session
        load_instance=True

    emails = ma.Nested(EmailSchema, many=True)
    phoneNumbers = ma.Nested(PhoneSchema, many=True)
    

    
