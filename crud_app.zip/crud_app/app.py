from flask import Blueprint
from flask_restful import Api
from resources.Hello import Hello
from resources.user_operation import Create_User
from resources.user_operation import Get_User_by_id
from resources.user_operation import Get_User_by_name
from resources.phone_operation import Add_User_Phone
from resources.user_operation import Delete_User
from resources.phone_operation import update_User_Phone
from resources.email_operation import Add_User_Email
from resources.email_operation import update_User_Email
api_bp = Blueprint('api', __name__)
api = Api(api_bp)

# Routes

api.add_resource(Hello, '/Hello')
api.add_resource(Create_User, '/User')
api.add_resource(Get_User_by_id, '/User_by_id')
api.add_resource(Get_User_by_name, '/User_by_name')
api.add_resource(Add_User_Phone, '/user_phone')
api.add_resource(Delete_User, '/delete_user')
api.add_resource(update_User_Phone, '/update_user_phone')
api.add_resource(Add_User_Email, '/user_email')
api.add_resource(update_User_Email, '/update_user_email')