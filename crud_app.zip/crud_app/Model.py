from flask import Flask
from marshmallow import Schema, fields, pre_load, validate,post_load
from flask_marshmallow import Marshmallow
from flask_sqlalchemy import SQLAlchemy



app = Flask(__name__)

# Order matters: Initialize SQLAlchemy before Marshmallow
db = SQLAlchemy(app)
ma = Marshmallow(app)

class Phone(db.Model):
    __tablename__ = "phone"
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.String(255))
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    user = db.relationship("User", back_populates="phoneNumbers")
    
class Email(db.Model):
    __tablename__ = "email"
    id = db.Column(db.Integer, primary_key=True)
    mail = db.Column(db.String(255))
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"),nullable=False)
    user = db.relationship("User", back_populates="emails")

class User(db.Model):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True)
    lastName = db.Column(db.String(255))
    firstName = db.Column(db.String(255))
    emails = db.relationship('Email',cascade="all, delete",back_populates="user")
    phoneNumbers = db.relationship('Phone',cascade="all, delete",back_populates="user")

    


