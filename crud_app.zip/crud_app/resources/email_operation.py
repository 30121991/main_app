from flask import jsonify, request
from flask_restful import Resource
import sys
import json
from Model import db,Email,User,Phone
from schema import db,ma,PhoneSchema,EmailSchema,UserSchema

users_schema = UserSchema(many=True)
user_schema = UserSchema()


class Add_User_Email(Resource):
        
    def put(self):
      try:
        datas=request.get_json(force=True)
        jdata=json.loads(datas)
        if not datas:
               return {'message': 'No input data provided'}, 400

        details = User.query.filter_by(id=jdata['id']).all()
        details=details[0]
        for emails in jdata['emails']:
            details.emails.append(Email(mail=emails))
        db.session.commit()
        return {"status": "success"}, 200
      except Exception as E :
        print(E)
        return {"status": "Fail", "data": E},500

        
class update_User_Email(Resource):
        
    def put(self):
      try:
        datas=request.get_json(force=True)
        
        if not datas:
               return {'message': 'No input data provided'}, 400
               
        jdata=json.loads(datas) 
        details = Email.query.filter(Email.id==jdata['emailid']).all()
        details=details[0]
        print(details)
        details.mail=jdata['newmail']
        db.session.commit()

        return {"status": "success"}, 200
      except Exception as E :
        print(E)
        return {"status": "Fail", "data": E},500        
        