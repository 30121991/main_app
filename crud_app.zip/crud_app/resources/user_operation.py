from flask import jsonify, request
from flask_restful import Resource
import sys
import json
from Model import db,Email,User,Phone
from schema import db,ma,PhoneSchema,EmailSchema,UserSchema

users_schema = UserSchema(many=True)
user_schema = UserSchema()

class Create_User(Resource):
        
    def post(self):
      try:
        json_data = request.get_json(force=True)
        if not json_data:
               return {'message': 'No input data provided'}, 400
        # Validate and deserialize input
        data, errors = user_schema.load(json.loads(json_data))
        if errors:
            return {"status": "error", "data": errors}, 422
        else:
            db.session.add(data) 
            db.session.commit()  
            return {"status": "success", "data": data.id}, 200
      except Exception as E :
        print(E)
        return {"status": "Fail", "data": E},500
        
class Get_User_by_id(Resource):
    def get(self):
    
      try: 
        ids= language = request.args.get('id')
        if not ids:
            return {'message': 'No input data provided'}, 400
        details = User.query.filter_by(id=ids)
        details = users_schema.dump(details).data
        return {"status":"success", "data":details}, 200
      except Exception as E :
        print(E)
        return {"status": "Fail", "data": E},500

class Get_User_by_name(Resource):
    def get(self):
     try:
      firstName=request.args.get('firstName')
      lastName=request.args.get('lastName')
      if firstName!=None or lastName!=None: 
        details = User.query.filter((User.firstName==firstName) & (User.lastName==lastName))
        detailss = users_schema.dump(details).data
        return {"status":"success", "data":detailss}, 200
      else:
        return {'message': 'Input data has not been sent properly'}, 400
     except Exception as E :
        print(E)
        return {"status": "Fail", "data": E},500
        
        

class Delete_User(Resource):
        
    def delete(self):
      try:
        ids = request.args.get('id')
        print(ids)
        if not id:
               return {'message': 'No input data provided'}, 400

        datas=User.query.filter_by(id=ids).all()
        datas=datas[0]
        db.session.delete(datas)
        db.session.commit()
        return {"status": "success"}, 200
      except Exception as E :
        print(E)
        return {"status": "Fail", "data": E},500        
        
        
        
