import json
import requests

def creating_users(dica):
    json_object = json.dumps(dica)   
    print(json_object)
    resp=requests.post("http://127.0.0.1:5000/api/User", json=json_object)


dicf={
    "lastName": "roy",
    "firstName": "suman",
    "emails": [
        {"mail": "roy.ch@gmail.com"},{"mail": "suman.lope@gmail.com"}],
    "phoneNumbers": [
        {"number": "777778890"},{"number": "444667790"}]
    
 }
######Creating New user################
creating_users(dicf)
########Get user by id################  
ids={'id':7}     
r = requests.get(url ="http://127.0.0.1:5000/api/User_by_id", params = ids)    
print(r.json())
#browser:http://127.0.0.1:5000/api/User_by_id?id=7

########Get user by Name################  
names={'firstName':'Kuntal','lastName':'Mitra'}     
r = requests.get(url ="http://127.0.0.1:5000/api/User_by_name", params = names)    
print(r.json())
#http://127.0.0.1:5000/api/User_by_name?firstName=Kuntal&lastName=Mitra

######Add additional Phone data ############
phones={'id':7,"phoneNumbers": ["2225556668","77744411122"]}
r = requests.put(url ="http://127.0.0.1:5000/api/user_phone", json = json.dumps(phones))

######Add additional email data ############
emails={'id':7,"emails": ["nnmmjjk@mail.com","ppllook@mail.com"]}
r = requests.put(url ="http://127.0.0.1:5000/api/user_email", json = json.dumps(emails))

###########update phone data##############
uphone={'phoneid':13,"newnumber": '033244139'}
r = requests.put(url ="http://127.0.0.1:5000/api/update_user_phone", json = json.dumps(uphone))
###########update email data##############
uemail={'emailid':17,"newmail": 'pepcity@gmail.com'}
r = requests.put(url ="http://127.0.0.1:5000/api/update_user_email", json = json.dumps(uemail))

#########Delete user by id ############################
del_id={'id':5} 
r = requests.delete(url ="http://127.0.0.1:5000/api/delete_user", params = del_id)